$(document).ready(function(){	

	$("head").append(`<style>
	.se {transform: scale(0.0)}
	.animate-box {transition : 0.4s}
	.item{transition : 0.4s}
	.item:hover{transform: rotate(15deg) scale(1.3);}
	.item:hover .animate-box {transform: rotate(8deg) scale(1.2)}
	.popup{position: fixed;width: 100%; height: 100vh; background: rgba(0,0,0,0.5); z-index:100; visibility: hidden;}
	.up {position: absolute; width: 1000px; height: 800px; background: white; top: -10%; left: 50%; transform: translate(-50%, 10%); opacity: 0}
	.cl {position: absolute; right: 20px; top: 20px; width: 100px; height: 40px;  background: #2E9AFE; border-radius: 5px; line-height: 40px; text-align: center; color: white;  cursor: pointer;}
	.prev {width: 100px; height: 40px; float: left;  position: relative; top: 50%; background: #2E9AFE; border-radius: 5px; line-height: 40px; text-align: center; color: white; left: 20px;  cursor: pointer;}
	.next {width: 100px; height: 40px; float: right;  position: relative; top: 50%; background: #2E9AFE; border-radius: 5px; line-height: 40px; text-align: center; color: white; right: 20px;  cursor: pointer;}
		</style>`)
	$('.open').css({"right":"300px"})
	$(".fh5co-menu-btn").click(function() {
		console.log("!23213");
		$("#fh5co-offcanvass").css({"right":"300px"})
	})
	$(".fh5co-offcanvass-close.js-fh5co-offcanvass-close").click(function() {
		$("#fh5co-offcanvass").css({"right":"0"})
	})
	$(window).scroll(function() {
		var st = $(window).scrollTop()
		var sh = $(window).height()
		var sp = st + sh
		$(".animate-box").each(function(){
			var it = $(this).offset().top;
			var ih = $(this).height()
			var ip = it + ih
			if(st <= it && sp >= ip){
				$(this).removeClass("se")
			}else{
				$(this).addClass("se")
			}
		})
	});
	var il = $(".item").length;
	$("#fh5co-board").append("<div class='item-box'></div><div class='item-box'></div><div class='item-box'></div><div class='item-box'></div>") 
	$(".item-box").css({
		"width": '25%',
		"height": "100%",
		"float": "left"
	});	
	//$(".item").appendTo(".item-box")
	for (var i = 1; i <= il; i++){
		var code=`
			<div class="item">
				<div class="animate-box">
				<a class="image-popup fh5co-board-img" title="자동차${i}">
				<img src="images/img_${i}.jpg" alt="자동차${i}"></a></div><div class="fh5co-desc">자동차 갤러리 설명${i}
				</div>
			</div>
		`
		var ei = i%4-1;
		console.log(ei);
		$(".item-box").eq(ei).append(code);
	}
	$("#fh5co-board > .item").remove()
	$("body").prepend("<div class='popup'></div>")
	$(".popup").append("<div class='up'></div>")
	$(".up").prepend("<div class='cl'>닫기</div>")
	$(".up").prepend("<div class='prev'>이전</div>")
	$(".up").prepend("<div class='next'>다음</div>")
	$(".item").click(function(){
		$(".popup").css({"visibility": "visible"})
		$(".up").animate({
			opacity: 1,
			top:"1%"
		}, 300)
	})
	$(".cl").click(function(){
		$(".popup").css({"visibility": "hidden"})
	})

}) 